class Availability < ApplicationRecord
  belongs_to :doctor
end
